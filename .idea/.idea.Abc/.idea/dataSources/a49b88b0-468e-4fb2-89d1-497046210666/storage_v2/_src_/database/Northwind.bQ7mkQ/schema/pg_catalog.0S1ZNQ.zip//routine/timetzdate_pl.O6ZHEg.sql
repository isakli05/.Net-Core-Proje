create
functıon timetzdate_pl(time with time zone, date) returns timestamp with time zone
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select ($2 + $1)
$$;

comment on functıon timetzdate_pl(time with time zone, date) is 'implementation of + operator';

alter
functıon timetzdate_pl(time with time zone, date) owner to postgres;

