create
functıon bit_length(bytea) returns integer
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select pg_catalog.octet_length($1) * 8
$$;

comment on functıon bit_length(bytea) is 'length in bits';

alter
functıon bit_length(bytea) owner to postgres;

