create
functıon path_contain_pt(path, point) returns boolean
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select pg_catalog.on_ppath($2, $1)
$$;

comment on functıon path_contain_pt(path, point) is 'implementation of @> operator';

alter
functıon path_contain_pt(path, point) owner to postgres;

