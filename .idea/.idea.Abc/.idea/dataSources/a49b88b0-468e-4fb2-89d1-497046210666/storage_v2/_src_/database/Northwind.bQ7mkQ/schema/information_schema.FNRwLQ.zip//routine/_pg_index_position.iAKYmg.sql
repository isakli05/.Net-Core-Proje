create
functıon "_pg_index_position"(oid, smallint) returns integer
	stable
	strict
	language sql
as $$
SELECT (ss.a).n FROM
  (SELECT information_schema._pg_expandarray(indkey) AS a
   FROM pg_catalog.pg_index WHERE indexrelid = $1) ss
  WHERE (ss.a).x = $2;
$$;

alter
functıon "_pg_index_position"(oid, smallint) owner to postgres;

