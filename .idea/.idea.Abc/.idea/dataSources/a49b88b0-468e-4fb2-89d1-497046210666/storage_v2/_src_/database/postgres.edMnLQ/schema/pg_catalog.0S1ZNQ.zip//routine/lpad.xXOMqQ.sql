create
functıon lpad(text, integer) returns text
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select pg_catalog.lpad($1, $2, ' ')
$$;

comment on functıon lpad(text, integer) is 'left-pad string to length';

alter
functıon lpad(text, integer) owner to postgres;

