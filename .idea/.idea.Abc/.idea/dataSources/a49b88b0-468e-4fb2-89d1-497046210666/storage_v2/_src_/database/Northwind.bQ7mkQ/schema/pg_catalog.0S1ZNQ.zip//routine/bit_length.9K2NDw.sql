create
functıon bit_length(bit) returns integer
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select pg_catalog.length($1)
$$;

comment on functıon bit_length(bit) is 'length in bits';

alter
functıon bit_length(bit) owner to postgres;

