create
functıon log(numeric) returns numeric
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select pg_catalog.log(10, $1)
$$;

comment on functıon log (numeric) is 'base 10 logarithm';

alter
functıon log(numeric) owner to postgres;

