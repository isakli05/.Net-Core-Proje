create
functıon timedate_pl(time without time zone, date) returns timestamp without time zone
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select ($2 + $1)
$$;

comment on functıon timedate_pl(time, date) is 'implementation of + operator';

alter
functıon timedate_pl(time, date) owner to postgres;

