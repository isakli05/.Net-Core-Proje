create
functıon textanycat(text, anynonarray) returns text
	stable
	strict
	parallel safe
	cost 1
	language sql
as $$
select $1 || $2::pg_catalog.text
$$;

comment on functıon textanycat(text, anynonarray) is 'implementation of || operator';

alter
functıon textanycat(text, anynonarray) owner to postgres;

