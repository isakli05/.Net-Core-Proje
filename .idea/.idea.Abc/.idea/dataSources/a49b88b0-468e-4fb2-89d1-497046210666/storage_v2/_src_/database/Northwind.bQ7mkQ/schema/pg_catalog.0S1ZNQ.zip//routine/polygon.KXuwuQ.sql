create
functıon polygon(circle) returns polygon
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select pg_catalog.polygon(12, $1)
$$;

comment on functıon polygon(circle) is 'convert circle to 12-vertex polygon';

alter
functıon polygon(circle) owner to postgres;

