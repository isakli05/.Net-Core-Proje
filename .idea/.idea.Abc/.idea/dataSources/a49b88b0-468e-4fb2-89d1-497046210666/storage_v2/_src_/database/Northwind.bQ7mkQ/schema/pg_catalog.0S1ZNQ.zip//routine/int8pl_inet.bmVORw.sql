create
functıon int8pl_inet(bigint, inet) returns inet
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select $2 + $1
$$;

comment on functıon int8pl_inet(bigint, inet) is 'implementation of + operator';

alter
functıon int8pl_inet(bigint, inet) owner to postgres;

