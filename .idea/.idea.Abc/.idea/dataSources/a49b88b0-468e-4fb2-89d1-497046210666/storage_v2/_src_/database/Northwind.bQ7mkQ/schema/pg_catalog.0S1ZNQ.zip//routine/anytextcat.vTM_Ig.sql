create
functıon anytextcat(anynonarray, text) returns text
	stable
	strict
	parallel safe
	cost 1
	language sql
as $$
select $1::pg_catalog.text || $2
$$;

comment on functıon anytextcat(anynonarray, text) is 'implementation of || operator';

alter
functıon anytextcat(anynonarray, text) owner to postgres;

