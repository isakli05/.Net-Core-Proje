create
functıon interval_pl_timetz(interval, time with time zone) returns time with time zone
	ımmutable
	strict
	parallel safe
	cost 1
	language sql
as $$
select $2 + $1
$$;

comment on functıon interval_pl_timetz(interval, time with time zone) is 'implementation of + operator';

alter
functıon interval_pl_timetz(interval, time with time zone) owner to postgres;

